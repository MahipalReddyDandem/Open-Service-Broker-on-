export GRADLE_OPTS="-Dhttp.proxyHost=approxy.jpmchase.net -Dhttps.proxyHost=approxy.jpmchase.net -Dhttp.proxyPort=8080 -Dhttps.proxyPort=8080"
